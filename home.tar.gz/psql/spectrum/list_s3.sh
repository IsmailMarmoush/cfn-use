#!/bin/bash

aws s3 ls s3://awssampledbuswest2/tickit/spectrum/sales_partition/
