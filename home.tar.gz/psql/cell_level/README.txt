10 - 99 script to setup, test, and destroy cell-level secuirty
