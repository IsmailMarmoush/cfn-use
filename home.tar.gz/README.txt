README from home.tar.gz
Contains home directory contents
Will overwrite any existing files without warning
do not include .ssh directory 
shall I put pem in here for key creation?
don't inlcude .ssh directory stuff in hear or risk messing up ec2-user login
